import React from 'react'

const NotFound = () => {
  return (
    <div className='flex justify-center items-center'>
        <h1>404 Not Found </h1>
        <p>Anything else error please try again</p>
    </div>
  )
}

export default NotFound